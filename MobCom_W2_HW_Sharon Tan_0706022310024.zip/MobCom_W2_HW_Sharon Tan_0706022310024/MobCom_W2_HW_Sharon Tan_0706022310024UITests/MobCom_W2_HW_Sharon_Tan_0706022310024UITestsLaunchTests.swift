//
//  MobCom_W2_HW_Sharon_Tan_0706022310024UITestsLaunchTests.swift
//  MobCom_W2_HW_Sharon Tan_0706022310024UITests
//
//  Created by Nico Prasetyo on 20/09/25.
//

import XCTest

final class MobCom_W2_HW_Sharon_Tan_0706022310024UITestsLaunchTests: XCTestCase {

    override class var runsForEachTargetApplicationUIConfiguration: Bool {
        true
    }

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    func testLaunch() throws {
        let app = XCUIApplication()
        app.launch()

        // Insert steps here to perform after app launch but before taking a screenshot,
        // such as logging into a test account or navigating somewhere in the app

        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "Launch Screen"
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}

//
//  ContentView.swift
//  MobCom_W2_HW_Sharon Tan_0706022310024
//
//  Created by Sharon on 20/09/25.
//

import SwiftUI

struct ContentView: View {
    let todos = ["Buy Indomie", "Eat Cake", "Do Mobcom HW", "Jogging", "Prepare Dinner"]
    
    @State private var isDoneArray: [Bool] = [false, false, false, false, false]
    
    @State private var searchTodo:String = ""
    
    var body: some View {
        VStack (alignment: .leading){
            HStack{
                Text("TO DO LIST")
                    .font(.title)
                    .fontWeight(.bold)
                
                Spacer()
                
                Button("Add New"){
                    print("Added")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
            
            VStack{
                HStack{
                    TextField("Search...", text: $searchTodo)
                        .textFieldStyle(.roundedBorder)
                    
                    Button("Search", systemImage: "magnifyingglass") {
                        print("Searched Todo")
                    }
                }
                .padding(.top, 20)
                .padding(.horizontal, 20)
                .background(Color(UIColor.systemGray6))
                
                Text(isDoneArray.count(where: { $0 }) == todos.count ? "All Done ✅" : "")
                
                HStack{
                    List(todos.indices, id: \.self) {index in
                        HStack{
                            Text(todos[index])
                            Spacer()
                            Toggle("", isOn: $isDoneArray[index])
                                .toggleStyle(SwitchToggleStyle(tint: .green))
                        }
                    }
                }
                
            }
            .background(Color(UIColor.systemGray6))
        }
    }
}

#Preview {
    ContentView()
}

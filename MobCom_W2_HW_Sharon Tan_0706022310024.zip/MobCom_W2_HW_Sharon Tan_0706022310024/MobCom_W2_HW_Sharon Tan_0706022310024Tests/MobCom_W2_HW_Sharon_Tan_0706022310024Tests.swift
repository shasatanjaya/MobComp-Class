//
//  MobCom_W2_HW_Sharon_Tan_0706022310024Tests.swift
//  MobCom_W2_HW_Sharon Tan_0706022310024Tests
//
//  Created by Nico Prasetyo on 20/09/25.
//

import Testing
@testable import MobCom_W2_HW_Sharon_Tan_0706022310024

struct MobCom_W2_HW_Sharon_Tan_0706022310024Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

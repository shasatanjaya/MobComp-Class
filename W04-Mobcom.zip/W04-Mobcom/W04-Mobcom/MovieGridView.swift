//
//  MovieGridView.swift
//  W04-Mobcom
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieGridView: View {
    @Binding var search: String
    
    @ObservedObject var store: MovieStore
    
    let columns = [
            GridItem(.flexible()),
            GridItem(.flexible())
        ]
        
    var filteredMovies: [MovieStore.Movie] {
           if search.isEmpty {
               return store.movies
           } else {
               return store.movies.filter { $0.title.localizedCaseInsensitiveContains(search) }
           }
       }
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(filteredMovies) { movie in
                    NavigationLink(destination: MovieCard(movie: movie)) {
                        VStack {
                            AsyncImage(url: URL(string: movie.posterURL)) { phase in
                                if let image = phase.image {
                                    image
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 150, height: 250)
                                        .clipped()
                                        .cornerRadius(10)
                                        .shadow(radius: 10)
                                }
                                else {
                                    ProgressView().frame(height: 200)
                                }
                            }
                            Text(movie.title)
                                .font(.caption)
                                .lineLimit(1)
                        }
                    }
                    .buttonStyle(.plain)
                }
                .padding()
            }
        }
            
    }
}

//#Preview {
//    MovieGridView(search: search)
//}

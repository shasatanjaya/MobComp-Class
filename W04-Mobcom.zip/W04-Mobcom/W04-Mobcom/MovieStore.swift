//
//  MovieStore.swift
//  W04-Mobcom
//
//  Created by student on 02/10/25.
//

import SwiftUI
import Combine

class MovieStore: ObservableObject {
    
    struct Movie: Identifiable {
        let id = UUID()
        let title: String
        let posterURL: String
        let genres: [String]
        let sinopsis: String
        let casts: [String]
    }
    
    @Published var movies: [Movie] = [
        Movie(title: "The Lion King (1994)",
              posterURL: "https://m.media-amazon.com/images/M/MV5BZGRiZDZhZjItM2M3ZC00Y2IyLTk3Y2MtMWY5YjliNDFkZTJlXkEyXkFqcGc@._V1_QL75_UX380_CR0,1,380,562_.jpg",
              genres: ["Action", "Adventure"],
              sinopsis: "Lion prince Simba and his father are targeted by his bitter uncle, who wants to ascend the throne himself.",
              casts: ["Simba", "Scar", "Some animals"]),
        
        Movie(title: "Beauty and The Beast (1991)",
              posterURL: "https://m.media-amazon.com/images/M/MV5BYTY3NDg2YzktYWFjZC00MTExLTlmZDctMGY3MWYzZTlkYTNiXkEyXkFqcGc@._V1_.jpg",
              genres: ["Romance", "Slice of Life", "Family"],
              sinopsis: "A prince cursed to spend his days as a hideous monster sets out to regain his humanity by earning a young woman's love.",
              casts: ["Belle", "the BEAST", "Gaston", "Furnitures"]),
        
        Movie(title: "The Little Mermaid (1989)",
              posterURL: "https://m.media-amazon.com/images/M/MV5BNmQ3ODcyZGMtMjNlOS00YzhlLTg0YzAtZGVjNmQ0OTYyNDg0XkEyXkFqcGc@._V1_.jpg",
              genres: ["Romance", "Adventure"],
              sinopsis: "A mermaid princess makes a Faustian bargain in an attempt to become human and win a prince's love",
              casts: ["Ariel", "Poisedon", "Eric", "Fishes", "Queen"]),
        
        Movie(title: "Finding Nemo (2003)",
              posterURL: "https://m.media-amazon.com/images/M/MV5BMTc5NjExNTA5OV5BMl5BanBnXkFtZTYwMTQ0ODY2._V1_.jpg",
              genres: ["Action", "Adventure"],
              sinopsis: "After his son is captured in the Great Barrier Reef and taken to Sydney, a timid clownfish sets out on a journey to bring him home.",
              casts: ["Nemo", "Nemo's Dad", "Fishes", "Shark", "Dori"]),
        
        Movie(title: "Tangled (2010)",
              posterURL: "https://m.media-amazon.com/images/M/MV5BMTAxNDYxMjg0MjNeQTJeQWpwZ15BbWU3MDcyNTk2OTM@._V1_FMjpg_UX1000_.jpg",
              genres: ["Romance", "Adventure"],
              sinopsis: "The magically long-haired Rapunzel has spent her entire life in a tower, but now that a runaway thief has stumbled upon her, she is about to discover the world for the first time, and who she really is.",
              casts: ["Rapunzel", "Eugene", "Mother Gothel", "Lampions"])
    ]
}

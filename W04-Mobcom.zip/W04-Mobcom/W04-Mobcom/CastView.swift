//
//  CastView.swift
//  W04-Mobcom
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct CastView: View {
    let cast: [String]
    let title: String
    
    var body: some View {
        List(cast, id: \.self) { cast in
            Text(cast)
                .font(.body)
                .padding(.vertical, 6)
        }
        .navigationTitle("Cast of \(title)")
        .navigationBarTitleDisplayMode(.inline)
    }
}

//#Preview {
//    CastView()
//}

//
//  MovieCard.swift
//  W04-Mobcom
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct MovieCard: View {
    let movie: MovieStore.Movie
    
    var body: some View {
            
            VStack(spacing: 20) {
                
                AsyncImage(url: URL(string: movie.posterURL)) { phase in
                    if let image = phase.image {
                        image
                            .resizable()
                            .scaledToFit()
                            .cornerRadius(12)
                            .shadow(radius: 10)
                    } else {
                        ProgressView()
                    }
                }
                .frame(maxHeight: 200)
                
                Text(movie.title)
                    .font(.headline)
                    .multilineTextAlignment(.leading)
                
                HStack {
                    ForEach(movie.genres, id: \.self) { genre in
                        Text(genre)
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
                
                
                
                Text(movie.sinopsis)
                    .font(.caption)
                    .multilineTextAlignment(.leading)
                
                
                NavigationLink(destination: CastView(cast: movie.casts, title: movie.title)) {
                                Text("See Cast Details")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .padding()
                                    .background(Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                
                
                Spacer()
            }
            .padding()
            .navigationTitle(movie.title)
            .navigationBarTitleDisplayMode(.inline)
    }
}

//#Preview {
//    MovieCard()
//}

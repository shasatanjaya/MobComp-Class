//
//  W04_MobcomApp.swift
//  W04-Mobcom
//
//  Created by student on 02/10/25.
//

import SwiftUI

@main
struct W04_MobcomApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

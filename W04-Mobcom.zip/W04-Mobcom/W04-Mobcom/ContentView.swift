//
//  ContentView.swift
//  W04-Mobcom
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct ContentView: View {
    @State private var search:String = ""
    @StateObject var store = MovieStore()
    
    let columns = [
            GridItem(.flexible()),
            GridItem(.flexible()),
        ]
    

    var body: some View {
        NavigationStack{
            VStack {
                HStack{
                    
                    Text("UCFlix")
                        .font(.title)
                        .padding(.horizontal)
                        .padding(.vertical, 6)
                        .background(.white.opacity(0.8))
                        .cornerRadius(16)
                        .foregroundColor(.green)
                        .bold()
                    
                    Spacer()
                    
                    TextField("Search movies...", text: $search)
                        .padding(.leading, 30)
                        .padding(10)
                        .background(Color(.systemGray6))
                        .cornerRadius(16)
                        .overlay(
                            HStack {
                                Image(systemName: "magnifyingglass")
                                    .foregroundColor(.gray)
                                    .padding(.leading, 8)
                                Spacer()
                            }
                        )
                        .padding(.horizontal)
                    
                    
                }
                .padding()
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.green, Color.blue]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                
                HStack {
                    Text("Top Movies")
                        .fontWeight(.bold)
                        .font(.title2)
                        
                    Spacer()
                }
                .padding(.leading, 23)
                .padding(.top, 10)

                MovieGridView(search: $search, store: store)
                
                
            }

        }
    }
}

#Preview {
    ContentView()
}

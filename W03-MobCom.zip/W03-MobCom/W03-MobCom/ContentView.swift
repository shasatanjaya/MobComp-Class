//
//  ContentView.swift
//  W03-MobCom
//
//  Created by student on 25/09/25.
//

import SwiftUI


// MVVM - Model View ViewModel

struct ContentView: View {
    // struct itu immutable (gabisa diganti)
    // State itu propertynya struct
    
    
    @State private var number = 0
    // state adalah property wrapper, yg ngebantu...
    // -> kalo ga pake @State variablenya tidak bisa diubah (walaupun var)
    
    @State private var count = 0
    @State private var nama = ""
    
    @State private var totalCount = 0
    //buat Binding tadi
    
    
    var body: some View {
        //STRUCT
        //        VStack {
        
        //            Text("Hitung: \(count)")
        //                .font(.largeTitle)
        //            Text("Nama: \(nama)")
        //
        //            TextField("Isi Nama", text: $nama)
        //                .textFieldStyle(RoundedBorderTextFieldStyle())
        //
        //            HStack{
        //                Button("-"){
        //                    count -= 1
        //                }
        //                .font(.title)
        //                .buttonStyle(.borderedProminent)
        //                .bold()
        //
        //                Button("+"){
        //                    count += 1
        //                }
        //                .font(.title)
        //                .buttonStyle(.borderedProminent)
        //                .bold()
        //            }
        
        // BINDING
        //            Text("Parent View")
        //                .font(.largeTitle)
        //
        //            Text("Total Count: \(totalCount)")
        //                .font(.title)
        //                .padding()
        //
        //            CounterView(count: $totalCount)
        //            Spacer()
        //        }
        //        .padding()
        //        .background(.yellow.opacity(0.3))
        
        // TABVIEW
        //        TabView {
        //            HomeView()
        //                .tabItem{
        //                    Label("Home", systemImage: "house.fill")
        //                }
        //                .badge("3")
        //
        //            SearchView()
        //                .tabItem {
        //                    Label("Search", systemImage: "magnifyingglass")
        //                }
        //
        //            ProfileView()
        //                .tabItem {
        //                    Label("Profile", systemImage: "person.fill")
        //                }
        //
        //        }
        //        .tint(.green)
        //
        
        NavigationStack{
            VStack (spacing: 20){
                Text("🏡 Home Screen")
                    .font(.largeTitle)
                
                NavigationLink("Go to Details") {
                    DetailScreen()
                }
                
                NavigationLink("Show Pets") {
                    ItemScreen()
                }
            }
        }
        
        
    }
}

// navigation
struct DetailScreen: View {
    var body: some View {
        VStack{
            Text("📑 Detail Screen")
                .font(.largeTitle)
            
            Text("Welcome Home! ❤️")
        }
        .navigationTitle("Detail")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ItemScreen: View {
    let items = ["Cat 🐱", "Dog 🐶", "Rabbit 🐰", "Hamster 🐹", "Snake 🐍"]
    
    var body: some View {
        NavigationStack{
            List(items, id: \.self) {
                item in NavigationLink(destination: ItemDetailScreen(item: item)) {
                    Text(item)
                }
            }
            .navigationTitle("Pets")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct ItemDetailScreen: View {
    let item: String
    
    var body: some View {
        VStack{
            Text("🏠 Pet Home 🐾")
                .font(.title)
            Text("You've Selected: \(item)")
        }
        .navigationTitle(item)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// Tabview
struct HomeView: View {
    @State private var textKu=""
    
    var body: some View {
        Form{
            VStack(alignment: .center){
                Text("🏡 Home!")
                    .font(.largeTitle)
                    .fontWeight(.medium)
                
                //                TextField("Name", text:$textKu)
                //                    .border(Color.gray)
                //                    .padding()
            }
        }
        .padding()
        .background(Color.green.opacity(0.2))
    }
}

struct SearchView: View {
    
    var body: some View {
        VStack{
            Text("🔍 Search!")
                .font(.largeTitle)
        }
    }
}

struct ProfileView: View {
    
    var body: some View {
        VStack{
            Text("🙋🏻‍♀️ Profile!")
                .font(.largeTitle)
        }
    }
}


#Preview {
    ContentView()
}

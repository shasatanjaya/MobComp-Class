//
//  CounterView.swift
//  W03-MobCom
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct CounterView: View {
    @Binding var count: Int
    //Biar bisa bawa value ke struct/view lainnnya
    //passing value
    
    var body: some View {
        
        VStack{
            Text("Child View (CounterView)")
                .font(.headline)
            
            HStack{
                Button("-"){
                    count -= 1
                }
                .font(.title)
                .buttonStyle(.borderedProminent)
                .bold()
                
                Button("+"){
                    count += 1
                }
                .font(.title)
                .buttonStyle(.borderedProminent)
                .bold()
            }
        }
        .padding()
        .background(.blue.opacity(0.8))
        .cornerRadius(10)
    }
}

//#Preview {
//    CounterView()
//}

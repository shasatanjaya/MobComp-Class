//
//  W03_MobComApp.swift
//  W03-MobCom
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03_MobComApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

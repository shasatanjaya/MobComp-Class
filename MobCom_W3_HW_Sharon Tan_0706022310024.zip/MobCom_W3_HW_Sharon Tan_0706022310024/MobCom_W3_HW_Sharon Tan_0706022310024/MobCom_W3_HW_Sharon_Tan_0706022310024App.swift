//
//  MobCom_W3_HW_Sharon_Tan_0706022310024App.swift
//  MobCom_W3_HW_Sharon Tan_0706022310024
//
//  Created by Nico Prasetyo on 28/09/25.
//

import SwiftUI

@main
struct MobCom_W3_HW_Sharon_Tan_0706022310024App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

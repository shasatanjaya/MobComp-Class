//
//  ContentView.swift
//  MobCom_W3_HW_Sharon Tan_0706022310024
//
//  Created by Sharon on 28/09/25.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem{
                    Label("Home", systemImage: "house.fill")
                }
            
            ListView()
                .tabItem{
                    Label("Activity", systemImage:"list.bullet.clipboard.fill")
                }
            
            StatView()
                .tabItem {
                    Label("Statistic", systemImage: "chart.bar.xaxis.ascending")
                }
            
            ProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.fill")
                }
        }
        .tint(.green)
        
    }
}

#Preview {
    ContentView()
}

struct HomeView: View {
    @State private var search:String = ""
    
    var body: some View {
        
        VStack(spacing: 20){
            HStack{
                
                VStack(alignment: .leading, spacing: 5){
                    Text("Good Morning,")
                        .font(.title2)
                    Text("Sharon")
                        .font(.largeTitle)
                        .bold()
                }
                Spacer()
                Image("self-photo")
                    .resizable()
                    .frame(width: 70, height: 70)
                    .cornerRadius(24)
            }
            .padding(.horizontal)
            
            TextField("Search", text: $search)
                .padding()
                .background(.white)
                .cornerRadius(16)
                .padding(.horizontal)
            
            
            //Today's Goal
            VStack{
                Text("Today's Goal")
                    .font(.title)
                    .padding(.top, 30)
                    .bold()
                    .foregroundColor(.white)
                
                Spacer()
                
                HStack{
                    VStack(spacing: 5){
                        Image(systemName: "figure.run")
                            .imageScale(.large)
                            .font(.system(size: 50))
                        
                        Text("5 Miles")
                            .font(.title)
                            .bold()
                        
                        Text("@ Northwest")
                            .font(.subheadline)
                    }
                    .frame(width: 120)
                    .foregroundColor(.white)
                    .padding()
                    .background(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.white.opacity(0.4),
                                Color.white.opacity(0.02)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                        .background(.ultraThinMaterial)
                    )
                    .cornerRadius(20)
                    
                    
                    VStack(spacing: 5){
                        Image(systemName: "basketball.fill")
                            .imageScale(.large)
                            .font(.system(size: 50))
                        
                        Text("2 Hours")
                            .font(.title)
                            .bold()
                        
                        Text("@ UC Sport")
                            .font(.subheadline)
                    }
                    .frame(width: 120)
                    .foregroundColor(.white)
                    .padding()
                    .background(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.white.opacity(0.4),
                                Color.white.opacity(0.02)
                            ]),
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                        .background(.ultraThinMaterial)
                    )                    .cornerRadius(20)
                }
                .padding(.bottom,20)
                
                
                
            }
            .frame(width: 350, height: 280)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.green, Color.blue]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .cornerRadius(24)
            
            //Kotak 4
            VStack(alignment: .leading){
                //Atas
                HStack(spacing: 10){
                    ZStack{
                        RoundedRectangle(cornerRadius: 24)
                            .fill(.white)
                            .frame(width: 170, height: 100)
                            .cornerRadius(20)
                        
                        HStack{
                            
                            Image(systemName: "bolt.heart.fill")
                                .imageScale(.large)
                                .font(.system(size: 25))
                                .padding(.trailing, 15)
                                .padding(.bottom, 40)
                                .foregroundColor(.red)
                            
                            Text("78 Bpm")
                                .font(.title2)
                                .padding(.top, 50)
                            
                        }
                    }
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 24)
                            .fill(.white)
                            .frame(width: 170, height: 100)
                            .cornerRadius(20)
                        
                        HStack{
                            Image(systemName: "flame.fill")
                                .imageScale(.large)
                                .font(.system(size: 25))
                                .padding(.trailing, 20)
                                .padding(.bottom, 40)
                                .foregroundColor(.orange)

                            
                            Text("50 Kcal")
                                .font(.title2)
                                .padding(.top, 50)
                            
                        }
                    }
                    
                    
                }
                
                //Bawah
                HStack(spacing: 10){
                    ZStack{
                        RoundedRectangle(cornerRadius: 24)
                            .fill(.white)
                            .frame(width: 170, height: 100)
                            .cornerRadius(20)
                        
                        HStack{
                            Image(systemName: "scalemass.fill")
                                .imageScale(.large)
                                .font(.system(size: 25))
                                .padding(.trailing, 30)
                                .padding(.bottom, 40)
                                .foregroundColor(.mint)
                            
                            Text("55 Kg")
                                .font(.title2)
                                .padding(.top, 50)
                            
                        }
                    }
                    
                    ZStack{
                        RoundedRectangle(cornerRadius: 24)
                            .fill(.white)
                            .frame(width: 170, height: 100)
                            .cornerRadius(20)
                        
                        HStack{
                            Image(systemName: "powersleep")
                                .imageScale(.large)
                                .font(.system(size: 25))
                                .padding(.trailing, 20)
                                .padding(.bottom, 40)
                                .foregroundColor(.blue)
                            
                            Text("5.8 Hr")
                                .font(.title2)
                                .padding(.top, 50)
                            
                        }
                    }
                    
                    
                }
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        
    }
}

struct ListView: View {
    var body: some View {
        Text("List Activity")
    }
}


struct StatView: View {
    var body: some View {
        Text("Statistics")
    }
}

struct ProfileView: View {
    var body: some View {
        Text("Profile")
    }
}


//
//  W02_MobComTests.swift
//  W02-MobComTests
//
//  Created by student on 18/09/25.
//

import Testing
@testable import W02_MobCom

struct W02_MobComTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

//
//  ContentView.swift
//  W02-MobCom
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    //Declare Variable
    @State private var isOn:Bool = false
    @State private var volume:Double = 0.5
    @State private var nama:String = ""
    
    @State private var point = 80
    
    private func progressCard(score: Int) -> some View {
        VStack(){
            Text("Current Score").font(.headline)
            ProgressView(value: Double(score), total: 100)
            Text("\(score)/100")
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(.green.opacity(0.3))
        .clipShape(RoundedRectangle(cornerRadius: 24))
        
    }
    private func actionButton(_ title: String, action: @escaping () -> Void) -> some View {
        Button(title, action:action)
            .padding(.horizontal,16)
            .padding(.vertical,10)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
    }
    
    let fruits = ["Apple", "Orange", "Banana"]
    
    var body: some View {
        
        List(fruits, id: \.self) {fruit in
            HStack{
                Text(fruit)
                Spacer()
                Text("Sehat+")
            }
        }
        // Container
        //        VStack(alignment: .leading, spacing: 10)
        //        {
        //            //kalo titiknya 2 (..<) berati dia kurang dari 1 sampe 9 | kalo (...) itu 1 sampe 10
        //            ForEach(1...10, id: \.self)
        //            {
        //                Text("Item \($0)")
        //            }
        //        }
        //        .padding()
        //        .background(Color.mint.opacity(0.3))
        
        //SPACER
        //        VStack(spacing: 8)
        //        {
        //            Text("Sharon Tan")
        //            Text("Pangkalan Bun")
        //            Text("Shasa")
        //            Spacer()
        //        }
        //        .padding()
        //        .background(Color.mint.opacity(0.3))
        
        //        //ZSTACK
        //        ZStack{
        //            RoundedRectangle(cornerRadius: 24)
        //                .fill(.mint)
        //                .frame(width: 200, height: 125)
        //
        //            Text("Hi! I'm Sharon")
        //                .foregroundStyle(.white)
        //                .font(.title)
        //
        //            Circle()
        //                .fill(.white)
        //                .frame(width: 50, height: 50)
        //                .opacity(0.3)
        //        }
        
//        ZStack{
//            RoundedRectangle(cornerRadius: 24)
//                .fill(.green)
//                .frame(width: 200, height: 125)
//                .opacity(0.2)
//                .cornerRadius(20)
//            
//            HStack{
//                Text("Sharon")
//                    .foregroundColor(.green)
//                    .font(.title3)
//                    .padding(.trailing, 50)
//                    .padding(.bottom, 70)
//                
//                VStack{
//                    Text("🐈")
//                    Text("🥭 🍉")
//                }
//                .padding(.top, 50)
//                
//            }
//        }
        
//        ZStack{
//            RoundedRectangle(cornerRadius: 24)
//                .fill(.green)
//                .frame(width: 200, height: 125)
//                .opacity(0.2)
//                .cornerRadius(20)
//            
//            HStack{
//                Text("Sharon")
//                    .foregroundColor(.green)
//                    .font(.title3)
//                    .frame(width: 110, height: 100, alignment: .topLeading)
////                    .background(Color.red)
//                
//                VStack{
//                    Text("🐈")
//                    Text("🥭 🍉")
//                }
//                .frame(width: 60, height: 100, alignment: .bottomTrailing)
////                .background(Color.cyan)
//                
//            }
//        }
        
//        VStack{
//            Text("Shadow Example")
//                .padding()
//                .background(Color.blue.opacity(0.3))
//                .cornerRadius(20)
//                .shadow(color: .black.opacity(0.5), radius: 2, x: 10, y: 10)
//                .opacity(0.7)
//        }
//        
//        VStack{
//            Button("Click me 1") {
//                print("Button Clicked")
//            }
//            .foregroundColor(.green)
//            .padding(10)
//            .background(Color.green.opacity(0.5))
//            .cornerRadius(24)
//        }
//        
//        VStack{
//            Button("Click me 2") {
//                print("Button Clicked 2")
//            }
//            .buttonStyle(BorderedButtonStyle())
//            .tint(.green)
//            .padding(.horizontal, 10)
//        }
//        
//        VStack{
//            Image(systemName: "person.fill.questionmark")
//                .symbolRenderingMode(.hierarchical)
//                .font(.system(size:30))
//                
//        }
        
        VStack{
            Toggle("Enable Notifications", isOn: $isOn)
                .padding()
            Text(isOn ? "Hore" : "Yahh")
            
            Slider(value: $volume, in: 0...1)
            Text("Volume sekarang: \(volume)%")
            
            TextField("Namamu Siapa?", text: $nama)
                .textFieldStyle(.roundedBorder)
                .padding()
//            Text("Hello \(nama)!")
            Text(nama == "" ? "Hai" : "Hai \(nama)!")
            
        }
       
        
        VStack{
            progressCard(score: point)
            HStack{
                actionButton("Add 10") {
                    point += 10
                }
                actionButton("Reset") {
                    point = 0
                }
            }
        }

        .padding()
        
    }
}

#Preview {
    ContentView()
}

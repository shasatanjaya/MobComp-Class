//
//  W02_MobComApp.swift
//  W02-MobCom
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct W02_MobComApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  ContentView.swift
//  W01-MobCom
//
//  Created by student on 11/09/25.
//

import SwiftUI


struct Student {
    var name: String
    var year: Int
    func display() -> String {
        "\(name) - \(year)"
    }
}

enum UserStatus {case offline, online, busy}

struct ContentView: View {
    let userName = "Nico"
    let scores = [90, 92, 91]
    let student = Student(name: "NP", year: 2)
    let status: UserStatus = .online
    
    var badge: String {
        scores.allSatisfy {$0 >= 85} ? "✅" : "❌"
    }
    
    var body: some View {
        
//        VStack(alignment: .leading, spacing:15) {
//            Text("Welcome back, \(userName)")
//                .font(.title)
//            
//            Text("Student: \(student.display())")
//            
//            Text("Status: \(status == .online ? "🟢 Online" : "🔴 Offline")")
//            
//            Text("Badge: \(badge)")
//        }
//        .padding(.top, 20)
        
        //        VStack {
        //            Image(systemName: "globe")
        //                .imageScale(.large)
        //                .foregroundStyle(.tint)
        //            Text("Hello, world!")
        //            //var [nama] -> value bisa diubah
        //            //let [nama] -> value tdk bisa diubah
        //
        //        }
        
//        VStack{
//            Text("Hello World")
//                .font(.largeTitle)
//                .fontWeight(.bold) //modifier
//                .padding(.horizontal)
//                .background(Color.blue)
//                .foregroundColor(.white)
//            
//            Text("Declarative UI | Live Preview | SwiftUI CoOl!")
//                .multilineTextAlignment(.center)
//                .font(.headline)
//                .padding()
//                .font(.headline)
//                .background(.ultraThinMaterial)
//                .clipShape(RoundedRectangle(cornerRadius: 20))
//            
//            HStack {
//                Image(systemName: "sparkles")
//                    .imageScale(.large)
//                    .font(.system(size: 80))
//                    .padding()
//                    .overlay(content: {
//                        Circle().stroke(.yellow.opacity(0.3),lineWidth:2)
//                    }
//                    )
//                    .foregroundColor(.yellow)
//                
//                Image(systemName: "✨") //Ga muncul. Kesimpulan: Emoji is Text
//                    .imageScale(.large)
//                
//                Text("✨")
//                    .font(.system(size: 100))
//                    .padding()
//                
//            }
//            
//            
//        }
        
//        VStack(alignment: .leading, spacing:15) {
//            
//            HStack(spacing: 12) {
//                Text("Do")
//                Text("Re")
//                Text("Mi")
//            }
//            
//            VStack(spacing: 12) {
//                Text("Do")
//                Text("Re")
//                Text("Mi")
//            }
//            
//            ZStack {
//                Text("Do")
//                Text("Re")
//                Text("Mi")
//            }
//        }
        
//        HStack(spacing:15){
//            HStack{
//                Text("🤯")
//                    .font(.system(size: 50))
//                Text("")
//                    .font(.system(size: 50))
//                Text("😎")
//                    .font(.system(size: 50))
//            }
//            
//            ZStack{
//                Text("🫶")
//                    .font(.system(size: 120))
//                Text("🤩")
//                    .font(.system(size: 30))
//                    .padding(.leading, 10)
//                    .padding(.bottom, 2)
//                Text("")
//                    .font(.system(size: 50))
//            }
//            
//           VStack{
//                Text("😮")
//                    .font(.system(size: 50))
//                Text("👕")
//                    .font(.system(size: 100))
//                Text("👖")
//                    .font(.system(size: 100))
//            }
//        }\
        
        
        
        //ASSIGNMENT
        
        VStack{
            
            Image("self_photo")
                .resizable()
                .frame(width: 300, height: 200)
                .clipShape(Circle())
                .shadow(color: Color.green.opacity(0.2), radius: 30)
                .padding(.bottom, 80)
                .padding(.top, 50)
            
            VStack(spacing:10){
                Text("Hi! I'm Sharon")
                    .padding()
                    .font(.system(size: 30, weight: .bold))
                    .foregroundColor(Color.white)
                    .background(Color.green)
                    .cornerRadius(16)
                
                Text("My age is 20")
                    .font(.system(size: 20, weight: .light))
                    .padding()
                    .background(Color.green.opacity(0.1))
                    .foregroundColor(Color.green)
                    .cornerRadius(16)
                
                Text("🍵 👽 🐈")
                    .font(.system(size: 50, weight: .light))
                    .padding()
                    .background(Color.green.opacity(0.1))
                    .cornerRadius(16)
            }
            .padding()
            
            Spacer()
        }
        .padding()
        
    }
    
    let name = "Alice"
    var age = 20
    func greet() {
        print("Hello \(name), Age \(age)")
    }
    
}

#Preview {
    ContentView()
}

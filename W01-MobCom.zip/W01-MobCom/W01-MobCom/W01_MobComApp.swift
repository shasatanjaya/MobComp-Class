//
//  W01_MobComApp.swift
//  W01-MobCom
//
//  Created by student on 11/09/25.
//

import SwiftUI

@main
struct W01_MobComApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
